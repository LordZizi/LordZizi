#!/usr/bin/env python3
"""Inspect a GLB/glTF-binary 3D model for game-readiness defects. Pillow + numpy only.

Usage: python3 check_glb.py MODEL.glb [--budget 25000] [--json]

Reports: triangles and vertices per mesh and total (vs budget), materials and texture sizes,
bounding size (units, scale sanity), where the origin sits (feet / centre / off-model),
and geometry defects:
  - degenerate triangles (zero area)
  - duplicate triangles and coplanar overlapping faces -> z-fighting / flickering textures
  - boundary edges (holes in the surface) and non-manifold edges (3+ faces on one edge)
  - inconsistent winding (normals flipped against neighbours -> dark or invisible faces)
  - UVs missing, outside 0..1, or heavy UV overlap (two areas painted with the same texels)
  - textures not power of two or very large
Node transforms are ignored (meshes are read in their own space); skinned meshes still report.
"""
import argparse, json, struct, sys, io

import numpy as np

CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def load(path):
    data = open(path, "rb").read()
    magic, ver, length = struct.unpack_from("<4sII", data, 0)
    if magic != b"glTF":
        sys.exit("Это не GLB (бинарный glTF). Конвертируйте в .glb (Magnific models3d_convert или Blender).")
    off, js, binc = 12, None, b""
    while off < length:
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk)
        elif ctype == 0x004E4942:
            binc = chunk
        off += 8 + clen
    return js, binc


def accessor(js, binc, i):
    acc = js["accessors"][i]
    n, comp = acc["count"], NC[acc["type"]]
    dt = np.dtype(CT[acc["componentType"]])
    if "bufferView" not in acc:
        return np.zeros((n, comp), dt)
    bv = js["bufferViews"][acc["bufferView"]]
    start = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = bv.get("byteStride", 0) or dt.itemsize * comp
    raw = np.frombuffer(binc, np.uint8, count=stride * (n - 1) + dt.itemsize * comp, offset=start)
    out = np.lib.stride_tricks.as_strided(raw, shape=(n, comp * dt.itemsize), strides=(stride, 1)).copy()
    arr = out.view(dt).reshape(n, comp).astype(np.float64)
    if acc.get("normalized") and dt.kind in "iu":
        arr /= np.iinfo(dt).max
    return arr


def image_size(js, binc, img):
    if "bufferView" not in img:
        return None
    bv = js["bufferViews"][img["bufferView"]]
    b = binc[bv.get("byteOffset", 0): bv.get("byteOffset", 0) + bv["byteLength"]]
    try:
        from PIL import Image
        return Image.open(io.BytesIO(b)).size
    except Exception:
        return None


def analyse_prim(pos, tri, uv):
    r = {}
    v0, v1, v2 = pos[tri[:, 0]], pos[tri[:, 1]], pos[tri[:, 2]]
    cr = np.cross(v1 - v0, v2 - v0)
    area2 = np.linalg.norm(cr, axis=1)
    scale = max(np.ptp(pos, 0).max(), 1e-9)
    degen = area2 < (scale * 1e-6) ** 2
    r["degenerate"] = int(degen.sum())
    # weld vertices by position so seams in UV/normals don't look like holes
    q = np.round(pos / (scale * 1e-5)).astype(np.int64)
    _, weld = np.unique(q, axis=0, return_inverse=True)
    weld = weld.reshape(-1)
    t = weld[tri][~degen]
    st = np.sort(t, 1)
    _, cnt = np.unique(st, axis=0, return_counts=True)
    r["duplicate_tris"] = int((cnt - 1).sum())
    # edges
    e = np.concatenate([t[:, [0, 1]], t[:, [1, 2]], t[:, [2, 0]]])
    es = np.sort(e, 1)
    uniq, inv, ecount = np.unique(es, axis=0, return_inverse=True, return_counts=True)
    r["boundary_edges"] = int((ecount == 1).sum())
    r["nonmanifold_edges"] = int((ecount > 2).sum())
    # winding consistency: a manifold edge shared by two faces should appear in opposite directions
    directed = e[:, 0] < e[:, 1]
    inv = inv.reshape(-1)
    pair = ecount[inv] == 2
    s = np.zeros(len(uniq), np.int64)
    np.add.at(s, inv[pair], np.where(directed[pair], 1, -1))
    r["flipped_edge_pairs"] = int((np.abs(s[ecount == 2]) == 2).sum())
    # coplanar overlap: faces with same plane and overlapping centroids (z-fighting candidates)
    nrm = cr[~degen] / np.maximum(area2[~degen], 1e-12)[:, None]
    cen = (v0 + v1 + v2)[~degen] / 3
    d = (nrm * cen).sum(1)
    key = np.concatenate([np.round(np.abs(nrm) * 50), np.round(np.abs(d)[:, None] / (scale * 2e-3)), np.round(cen / (scale * 5e-3))], 1).astype(np.int64)
    _, kc = np.unique(key, axis=0, return_counts=True)
    r["zfight_candidates"] = int((kc - 1).sum()) - r["duplicate_tris"]
    if uv is not None:
        r["uv_out_of_range"] = round(float(((uv < -0.001) | (uv > 1.001)).any(1).mean()), 3)
        u = uv[tri[~degen]]
        uv_area = 0.5 * np.abs((u[:, 1, 0] - u[:, 0, 0]) * (u[:, 2, 1] - u[:, 0, 1]) - (u[:, 2, 0] - u[:, 0, 0]) * (u[:, 1, 1] - u[:, 0, 1]))
        res = 256
        cov = np.zeros((res, res), np.int32)
        cu = np.clip((u.mean(1) % 1.0) * res, 0, res - 1).astype(int)
        np.add.at(cov, (cu[:, 1], cu[:, 0]), 1)
        # rasterise roughly: count texel cells hit by more than one triangle (by centroid density)
        r["uv_total_area"] = round(float(uv_area.sum()), 3)
        r["uv_overlap_hint"] = round(float(max(uv_area.sum() - 1.0, 0)), 3)
    else:
        r["uv_missing"] = True
    return r


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("model")
    p.add_argument("--budget", type=int, help="triangle budget, e.g. 25000")
    p.add_argument("--json", action="store_true")
    a = p.parse_args()
    js, binc = load(a.model)
    rep = {"meshes": [], "issues": []}
    tot_t = tot_v = 0
    allpos = []
    agg = {k: 0 for k in ("degenerate", "duplicate_tris", "boundary_edges", "nonmanifold_edges", "flipped_edge_pairs", "zfight_candidates")}
    uv_out, uv_over, uv_missing = 0.0, 0.0, False
    for mi, m in enumerate(js.get("meshes", [])):
        for pi, pr in enumerate(m["primitives"]):
            if pr.get("mode", 4) != 4:
                continue
            pos = accessor(js, binc, pr["attributes"]["POSITION"])
            idx = accessor(js, binc, pr["indices"]).astype(np.int64).reshape(-1) if "indices" in pr else np.arange(len(pos))
            tri = idx[: len(idx) // 3 * 3].reshape(-1, 3)
            uv = accessor(js, binc, pr["attributes"]["TEXCOORD_0"]) if "TEXCOORD_0" in pr["attributes"] else None
            r = analyse_prim(pos, tri, uv)
            r.update(mesh=m.get("name", f"mesh{mi}"), prim=pi, tris=len(tri), verts=len(pos), material=pr.get("material"))
            rep["meshes"].append(r)
            tot_t += len(tri); tot_v += len(pos); allpos.append(pos)
            for k in agg:
                agg[k] += r.get(k, 0)
            uv_out = max(uv_out, r.get("uv_out_of_range", 0)); uv_over = max(uv_over, r.get("uv_overlap_hint", 0)); uv_missing |= r.get("uv_missing", False)
    if not allpos:
        sys.exit("В файле нет треугольной геометрии.")
    P = np.concatenate(allpos)
    mn, mx = P.min(0), P.max(0)
    size = mx - mn
    rep.update(triangles=tot_t, vertices=tot_v, size=[round(float(s), 3) for s in size], bbox_min=[round(float(v), 3) for v in mn], **agg)
    rep["materials"] = len(js.get("materials", []))
    rep["textures"] = [image_size(js, binc, im) for im in js.get("images", [])]
    rep["skinned"] = bool(js.get("skins"))
    rep["animations"] = [an.get("name", "") for an in js.get("animations", [])]
    I = rep["issues"]
    if a.budget and tot_t > a.budget:
        I.append(f"Треугольников {tot_t}, бюджет {a.budget}: нужен ремеш/ретопология.")
    tall = size.max()
    if tall > 50 or tall < 0.05:
        I.append(f"Подозрительный масштаб: наибольший размер {tall:.3g} ед. (для персонажа в метрах ожидается ~1-2.5). Проверьте единицы при экспорте.")
    up = int(np.argmax(size)) if size[1] < 0.3 * size.max() else 1
    foot = mn[1]
    if abs(foot) > 0.05 * size[1] and up == 1:
        where = "под ногами" if foot > 0 else "выше ног"
        I.append(f"Пивот не на уровне ног: низ модели на Y={foot:.3g} (ноль {where}). Персонаж будет висеть или проваливаться в пол.")
    if agg["degenerate"]:
        I.append(f"Вырожденные треугольники: {agg['degenerate']} (нулевая площадь) - мусор после генерации/ремеша.")
    if agg["duplicate_tris"]:
        I.append(f"Дублирующиеся треугольники: {agg['duplicate_tris']} - мерцание (z-fighting) и лишние полигоны.")
    if agg["zfight_candidates"] > 0.002 * tot_t:
        I.append(f"Наложение граней: {agg['zfight_candidates']} пар почти совпадающих копланарных граней - текстуры будут мерцать (z-fighting). Удалить внутренние дубли (Merge by distance, удаление внутренних граней).")
    if agg["nonmanifold_edges"]:
        I.append(f"Неманифолдные рёбра: {agg['nonmanifold_edges']} (на ребре 3+ грани) - проблемы с ригом, булевыми операциями, запеканием.")
    if agg["boundary_edges"] > 0.01 * tot_t:
        I.append(f"Открытые края: {agg['boundary_edges']} граничных рёбер - дыры в поверхности (видно насквозь под некоторыми углами).")
    if agg["flipped_edge_pairs"] > 0.002 * tot_t:
        I.append(f"Перевёрнутые нормали: {agg['flipped_edge_pairs']} рёбер между гранями с противоположной ориентацией - тёмные или невидимые участки. Recalculate Outside.")
    if uv_missing:
        I.append("Нет UV-развёртки хотя бы у одной части: текстура не ляжет.")
    if uv_out > 0.02:
        I.append(f"UV выходят за 0..1 у {uv_out:.0%} вершин: текстура будет повторяться там, где не должна (если не задуман тайлинг).")
    if uv_over > 0.15:
        I.append(f"Сумма площадей UV-островов больше квадрата на {uv_over:.2f}: острова перекрываются, одни и те же пиксели текстуры легли на разные части модели (при запекании - грязь).")
    for t in rep["textures"]:
        if t and ((t[0] & (t[0] - 1)) or (t[1] & (t[1] - 1))):
            I.append(f"Текстура {t[0]}x{t[1]} не степень двойки.")
        if t and max(t) > 4096:
            I.append(f"Текстура {t[0]}x{t[1]}: для игры обычно хватает 2048, больше - лишняя память.")
    if rep["materials"] > 4:
        I.append(f"Материалов {rep['materials']}: каждый - отдельный draw call, для пропса лучше 1-2 (атлас).")
    if not I:
        I.append("OK: явных проблем геометрии не найдено. Всё равно посмотрите рендер с 4 сторон.")
    if a.json:
        print(json.dumps(rep, ensure_ascii=False, indent=1, default=str))
        return
    print(f"{a.model}: {tot_t} треуг., {tot_v} верш., размер {rep['size']}, материалов {rep['materials']}, текстуры {rep['textures']}, риг {'есть' if rep['skinned'] else 'нет'}, анимации {rep['animations'] or 'нет'}")
    for m in rep["meshes"]:
        print("  ", {k: m[k] for k in ("mesh", "tris", "verts", "degenerate", "duplicate_tris", "zfight_candidates", "boundary_edges", "nonmanifold_edges", "flipped_edge_pairs") if k in m})
    for i in I:
        print(" -", i)


if __name__ == "__main__":
    main()
