#!/usr/bin/env python3
"""Check cutout PNG sprites for alpha defects.

Usage: python3 check_sprite.py IMAGE [IMAGE ...] [--preview OUT_DIR] [--json]

Reports per image: size, opaque bounding box, padding, whether the object touches the
canvas edge (cropped cut), share of semi-transparent pixels (soft edge / glow / halo),
halo colour contamination (light or dark fringe on the rim), stray islands (specks left by
background removal), interior holes (alpha 0 inside the silhouette), and missing alpha.
--preview writes the image over a checkerboard, black, white and magenta so a halo is visible.
Needs Pillow and numpy only.
"""
import argparse, json, os, sys
from collections import deque

import numpy as np
from PIL import Image


def components(mask):
    """Label 4-connected components of a boolean mask. Returns list of sizes and label array."""
    h, w = mask.shape
    labels = np.zeros((h, w), dtype=np.int32)
    sizes = []
    cur = 0
    ys, xs = np.nonzero(mask)
    for y0, x0 in zip(ys, xs):
        if labels[y0, x0]:
            continue
        cur += 1
        q = deque([(y0, x0)])
        labels[y0, x0] = cur
        n = 0
        while q:
            y, x = q.popleft()
            n += 1
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and not labels[ny, nx]:
                    labels[ny, nx] = cur
                    q.append((ny, nx))
        sizes.append(n)
    return sizes, labels


def dilate(mask, r=1):
    out = mask.copy()
    for _ in range(r):
        m = out.copy()
        m[1:, :] |= out[:-1, :]; m[:-1, :] |= out[1:, :]
        m[:, 1:] |= out[:, :-1]; m[:, :-1] |= out[:, 1:]
        out = m
    return out


def check(path, preview_dir=None):
    im = Image.open(path)
    res = {"file": os.path.basename(path), "size": list(im.size), "mode": im.mode, "issues": []}
    if im.mode not in ("RGBA", "LA", "PA") and "transparency" not in im.info:
        res["issues"].append("Нет альфа-канала: фон не вырезан (или это JPG). Для спрайта нужен PNG с прозрачностью.")
        return res
    a = np.asarray(im.convert("RGBA")).astype(np.int32)
    rgb, al = a[..., :3], a[..., 3]
    h, w = al.shape
    opaque = al >= 250
    visible = al > 8
    semi = (al > 8) & (al < 250)
    if not visible.any():
        res["issues"].append("Изображение полностью прозрачное.")
        return res
    ys, xs = np.nonzero(visible)
    x0, x1, y0, y1 = int(xs.min()), int(xs.max()), int(ys.min()), int(ys.max())
    res["bbox"] = [x0, y0, x1 + 1, y1 + 1]
    res["padding"] = {"left": x0, "top": y0, "right": w - 1 - x1, "bottom": h - 1 - y1}
    touch = [k for k, v in res["padding"].items() if v == 0]
    if touch:
        res["issues"].append(f"Объект касается края холста ({', '.join(touch)}): возможно, обрезан при генерации или вырезании.")
    semi_share = semi.sum() / max(visible.sum(), 1)
    res["semi_transparent_share"] = round(float(semi_share), 4)
    # rim = semi pixels within 2px of opaque core; far semi = glow/shadow residue
    core = dilate(opaque, 2)
    far_semi = semi & ~core
    res["far_semi_pixels"] = int(far_semi.sum())
    if far_semi.sum() > 0.02 * visible.sum():
        res["issues"].append(f"Полупрозрачная дымка вокруг объекта ({far_semi.sum()} px дальше 2 px от края): остатки тени, свечения или фона. На цветном фоне даст ореол.")
    # halo colour: compare rim colour brightness with interior near the rim
    rim = semi & core
    inner = opaque & dilate(semi, 3)
    if rim.sum() > 20 and inner.sum() > 20:
        lum = rgb @ np.array([0.2126, 0.7152, 0.0722])
        d = float(lum[rim].mean() - lum[inner].mean())
        res["rim_luma_delta"] = round(d, 1)
        if d > 40:
            res["issues"].append(f"Светлая кайма по краю (кромка светлее объекта на {d:.0f}): остаток белого/светлого фона. Нужна дефринж-обработка или повторное вырезание.")
        elif d < -40:
            res["issues"].append(f"Тёмная кайма по краю (кромка темнее объекта на {-d:.0f}): остаток тёмного фона или премультиплицированная альфа.")
    sizes, labels = components(visible)
    sizes_sorted = sorted(sizes, reverse=True)
    main = sizes_sorted[0]
    specks = [s for s in sizes_sorted[1:] if s < max(30, 0.002 * main)]
    res["islands"] = len(sizes)
    if specks:
        res["issues"].append(f"Мусорные пятна: {len(specks)} мелких островков отдельно от объекта (остатки фона после вырезания).")
    big_parts = [s for s in sizes_sorted[1:] if s >= max(30, 0.002 * main)]
    if big_parts:
        res["separate_parts"] = len(big_parts)
        res["issues"].append(f"Объект распался на {len(big_parts) + 1} крупных частей: проверьте, не вырезана ли перемычка (пояс, рукоять, шея) или это отдельные предметы.")
    # interior holes: transparent regions not connected to the border
    hole_sizes, hl = components(~visible)
    border_labels = set(np.unique(np.concatenate([hl[0], hl[-1], hl[:, 0], hl[:, -1]]))) - {0}
    holes = [s for i, s in enumerate(hole_sizes, 1) if i not in border_labels]
    if holes:
        res["holes"] = len(holes)
        big = [s for s in holes if s > 25]
        if big:
            res["issues"].append(f"Дыры внутри силуэта: {len(big)} шт. (крупнейшая {max(big)} px). Это может быть правильным (между рукой и телом) или ошибкой вырезания (прожжённое стекло, глаза, пряжка) - проверьте глазами.")
    if preview_dir:
        os.makedirs(preview_dir, exist_ok=True)
        rgba = Image.fromarray(a.astype(np.uint8), "RGBA")
        tiles = []
        cb = Image.new("RGBA", (w, h))
        px = np.indices((h, w)).sum(0) // 8 % 2
        cb = Image.fromarray(np.where(px[..., None] == 0, 200, 140).repeat(3, 2).astype(np.uint8)).convert("RGBA")
        for bg in (cb, Image.new("RGBA", (w, h), (0, 0, 0, 255)), Image.new("RGBA", (w, h), (255, 255, 255, 255)), Image.new("RGBA", (w, h), (255, 0, 255, 255))):
            tiles.append(Image.alpha_composite(bg, rgba))
        sheet = Image.new("RGBA", (w * 4, h))
        for i, t in enumerate(tiles):
            sheet.paste(t, (i * w, 0))
        out = os.path.join(preview_dir, os.path.splitext(os.path.basename(path))[0] + "_qa.png")
        sheet.convert("RGB").save(out)
        res["preview"] = out
    if not res["issues"]:
        res["issues"].append("OK: явных дефектов альфы не найдено.")
    return res


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("images", nargs="+")
    p.add_argument("--preview", help="folder for previews on checker/black/white/magenta")
    p.add_argument("--json", action="store_true")
    a = p.parse_args()
    out = [check(f, a.preview) for f in a.images]
    if a.json:
        print(json.dumps(out, ensure_ascii=False, indent=1))
        return
    for r in out:
        print(f"== {r['file']} {r['size'][0]}x{r['size'][1]} bbox={r.get('bbox')} semi={r.get('semi_transparent_share')}")
        for i in r["issues"]:
            print("  -", i)
        if r.get("preview"):
            print("  preview:", r["preview"])


if __name__ == "__main__":
    sys.exit(main())
