#!/usr/bin/env python3
"""Compare the colour palette of new images against an approved reference (the hero).

Usage: python3 compare_colors.py REFERENCE.png NEW1.png [NEW2.png ...] [--k 6] [--swatch OUT.png]

Extracts the k dominant colours of each image (ignoring transparent pixels and, with
--ignore-bg, a plain background), matches each reference colour to the nearest colour in the
new image and reports the distance in CIE76 Delta E: under 5 hardly visible, 5-12 noticeable,
over 12 a different colour (costume changed colour, skin tone drift, etc.).
Colours only: shape, details and accessories still need a visual item-by-item comparison.
"""
import argparse

import numpy as np
from PIL import Image, ImageDraw


def to_lab(rgb):
    c = rgb / 255.0
    c = np.where(c > 0.04045, ((c + 0.055) / 1.055) ** 2.4, c / 12.92)
    m = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]])
    xyz = c @ m.T / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[:, 1] - 16, 500 * (f[:, 0] - f[:, 1]), 200 * (f[:, 1] - f[:, 2])], 1)


def pixels(path, ignore_bg):
    im = Image.open(path).convert("RGBA")
    im.thumbnail((256, 256))
    a = np.asarray(im).reshape(-1, 4).astype(np.float32)
    px = a[a[:, 3] > 200][:, :3]
    if ignore_bg and len(px):
        corners = np.asarray(im)[[0, 0, -1, -1], [0, -1, 0, -1], :3].astype(np.float32).mean(0)
        px = px[np.abs(px - corners).sum(1) > 30]
    return px


def kmeans(px, k, iters=20, seed=0):
    rng = np.random.default_rng(seed)
    lab = to_lab(px)
    cent = lab[rng.choice(len(lab), size=min(k, len(lab)), replace=False)]
    for _ in range(iters):
        d = ((lab[:, None] - cent[None]) ** 2).sum(2)
        lbl = d.argmin(1)
        new = np.array([lab[lbl == i].mean(0) if (lbl == i).any() else cent[i] for i in range(len(cent))])
        if np.allclose(new, cent):
            break
        cent = new
    share = np.bincount(lbl, minlength=len(cent)) / len(lab)
    rgb = np.array([px[lbl == i].mean(0) if (lbl == i).any() else [0, 0, 0] for i in range(len(cent))])
    order = [i for i in share.argsort()[::-1] if share[i] > 0.005]
    return cent[order], share[order], rgb[order]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("reference")
    p.add_argument("images", nargs="+")
    p.add_argument("--k", type=int, default=6)
    p.add_argument("--ignore-bg", action="store_true", help="drop the plain background colour taken from the corners")
    p.add_argument("--swatch", help="write a swatch comparison PNG")
    a = p.parse_args()
    rl, rs, rr = kmeans(pixels(a.reference, a.ignore_bg), a.k)
    rows = [(a.reference, rr, rs, None)]
    print(f"Эталон {a.reference}: " + ", ".join(f"#{int(c[0]):02x}{int(c[1]):02x}{int(c[2]):02x} {s:.0%}" for c, s in zip(rr, rs)))
    for f in a.images:
        nl, ns, nr = kmeans(pixels(f, a.ignore_bg), a.k)
        d = np.sqrt(((rl[:, None] - nl[None]) ** 2).sum(2))
        nearest = d.min(1)
        weighted = float((nearest * rs).sum())
        worst = int(nearest.argmax())
        verdict = "OK" if weighted < 6 else ("заметный дрейф" if weighted < 12 else "цвета ушли")
        print(f"{f}: средний ΔE {weighted:.1f} - {verdict}; худший цвет эталона #{int(rr[worst][0]):02x}{int(rr[worst][1]):02x}{int(rr[worst][2]):02x} ({rs[worst]:.0%} площади) ушёл на ΔE {nearest[worst]:.1f}")
        rows.append((f, nr, ns, nearest))
    if a.swatch:
        sw = 40
        img = Image.new("RGB", (sw * a.k + 10, sw * len(rows)), (40, 40, 40))
        dr = ImageDraw.Draw(img)
        for r, (_, cols, _, _) in enumerate(rows):
            for i, c in enumerate(cols):
                dr.rectangle([i * sw, r * sw, (i + 1) * sw - 2, (r + 1) * sw - 2], fill=tuple(int(v) for v in c))
        img.save(a.swatch)
        print("swatch:", a.swatch)


if __name__ == "__main__":
    main()
