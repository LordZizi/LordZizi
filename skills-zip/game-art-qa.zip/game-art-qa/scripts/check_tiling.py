#!/usr/bin/env python3
"""Check whether a texture or tile repeats without visible seams.

Usage: python3 check_tiling.py TEXTURE.png [--preview OUT.png] [--grid 3]

Compares the left edge with the right edge and the top edge with the bottom edge
(what the engine places side by side), against the texture's own pixel-to-pixel variation.
Also flags a lighting gradient (one side brighter than the other), which shows as a
checker pattern when tiled even when the edges match.
--preview writes a 3x3 tiled image to look at.
"""
import argparse

import numpy as np
from PIL import Image


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("image")
    p.add_argument("--preview")
    p.add_argument("--grid", type=int, default=3)
    a = p.parse_args()
    im = Image.open(a.image).convert("RGB")
    x = np.asarray(im).astype(np.float32)
    h, w, _ = x.shape
    inner_h = np.abs(np.diff(x, axis=1)).mean()
    inner_v = np.abs(np.diff(x, axis=0)).mean()
    seam_h = np.abs(x[:, 0] - x[:, -1]).mean()
    seam_v = np.abs(x[0] - x[-1]).mean()
    rh, rv = seam_h / max(inner_h, 1e-3), seam_v / max(inner_v, 1e-3)
    print(f"{a.image}: {w}x{h}")
    print(f"  шов по горизонтали: {rh:.2f}x от обычного перепада соседних пикселей")
    print(f"  шов по вертикали:   {rv:.2f}x")
    issues = []
    if rh > 2.0:
        issues.append("Видимый шов при повторе по горизонтали (левый и правый края не совпадают).")
    if rv > 2.0:
        issues.append("Видимый шов при повторе по вертикали (верхний и нижний края не совпадают).")
    lum = x.mean(2)
    q = max(1, w // 4), max(1, h // 4)
    lr = abs(lum[:, : q[0]].mean() - lum[:, -q[0]:].mean())
    tb = abs(lum[: q[1]].mean() - lum[-q[1]:].mean())
    if max(lr, tb) > 12:
        issues.append(f"Градиент освещения ({max(lr, tb):.0f} уровней яркости между краями): при повторе будет «шахматка». Выровнять освещение (high-pass) перед использованием.")
    if (w & (w - 1)) or (h & (h - 1)):
        issues.append(f"Размер {w}x{h} не степень двойки: для текстур в движке лучше 512/1024/2048 (мипмапы, сжатие).")
    for i in issues or ["OK: швов и градиента не найдено."]:
        print("  -", i)
    if a.preview:
        g = a.grid
        out = Image.new("RGB", (w * g, h * g))
        for i in range(g):
            for j in range(g):
                out.paste(im, (i * w, j * h))
        out.save(a.preview)
        print("  preview:", a.preview)


if __name__ == "__main__":
    main()
