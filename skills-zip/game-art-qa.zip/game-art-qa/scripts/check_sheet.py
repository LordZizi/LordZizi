#!/usr/bin/env python3
"""Check a sprite sheet (or a folder of frames) for animation defects.

Usage:
  python3 check_sheet.py SHEET.png --cols 8 [--rows 1] [--gif OUT.gif] [--fps 12]
  python3 check_sheet.py FRAME_DIR/                     (frames sorted by name)

Per frame: opaque bbox, bottom line (feet), horizontal centre, height, colour count.
Flags: foot line jitter (character "floats" or "sinks"), horizontal drift, size pumping
(the figure grows/shrinks), empty frames, objects cut by the cell edge, palette shimmer
(frames using different colour sets), and a loop jump (last frame far from the first).
--gif writes a preview animation on a grey background to watch the loop.
"""
import argparse, glob, json, os, sys

import numpy as np
from PIL import Image


def load_frames(path, cols, rows):
    if os.path.isdir(path):
        files = sorted(glob.glob(os.path.join(path, "*.png")))
        return [Image.open(f).convert("RGBA") for f in files], [os.path.basename(f) for f in files]
    im = Image.open(path).convert("RGBA")
    if not cols:
        sys.exit("Для листа укажите --cols (и --rows, если строк больше одной).")
    rows = rows or 1
    w, h = im.size
    if w % cols or h % rows:
        print(f"! Размер листа {w}x{h} не делится на сетку {cols}x{rows}: ячейки разного размера, движок нарежет криво.")
    cw, ch = w // cols, h // rows
    frames, names = [], []
    for r in range(rows):
        for c in range(cols):
            frames.append(im.crop((c * cw, r * ch, (c + 1) * cw, (r + 1) * ch)))
            names.append(f"r{r}c{c}")
    return frames, names


def palette_key(rgb, mask, levels=16):
    q = (rgb[mask] // (256 // levels)).astype(np.int32)
    keys = q[:, 0] * levels * levels + q[:, 1] * levels + q[:, 2]
    vals, counts = np.unique(keys, return_counts=True)
    keep = vals[counts > max(3, 0.002 * mask.sum())]
    return set(keep.tolist())


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("path")
    p.add_argument("--cols", type=int)
    p.add_argument("--rows", type=int)
    p.add_argument("--gif")
    p.add_argument("--fps", type=int, default=12)
    p.add_argument("--json", action="store_true")
    a = p.parse_args()
    frames, names = load_frames(a.path, a.cols, a.rows)
    stats, issues = [], []
    pals = []
    for im, n in zip(frames, names):
        arr = np.asarray(im).astype(np.int32)
        al = arr[..., 3]
        vis = al > 8
        h, w = al.shape
        if not vis.any():
            stats.append({"frame": n, "empty": True})
            issues.append(f"Кадр {n} пустой.")
            pals.append(set())
            continue
        ys, xs = np.nonzero(vis)
        x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        s = {"frame": n, "bbox": [int(x0), int(y0), int(x1) + 1, int(y1) + 1], "bottom": int(y1),
             "cx": round(float(xs.mean()), 1), "height": int(y1 - y0 + 1), "width": int(x1 - x0 + 1)}
        edges = [k for k, v in (("left", x0 == 0), ("right", x1 == w - 1), ("top", y0 == 0), ("bottom", y1 == h - 1)) if v]
        if edges:
            issues.append(f"Кадр {n}: объект упирается в край ячейки ({', '.join(edges)}) - часть может быть обрезана или залезет в соседний кадр.")
        stats.append(s)
        pals.append(palette_key(arr[..., :3], al > 200))
    full = [s for s in stats if not s.get("empty")]
    if len(full) >= 2:
        b = np.array([s["bottom"] for s in full]); cx = np.array([s["cx"] for s in full]); hh = np.array([s["height"] for s in full])
        h_ref = float(np.median(hh))
        if b.max() - b.min() > max(2, 0.03 * h_ref):
            issues.append(f"Линия ног скачет на {b.max() - b.min()} px (кадры {full[int(b.argmin())]['frame']}..{full[int(b.argmax())]['frame']}): персонаж подпрыгивает или проваливается. Для ходьбы допустимо 1-3 px покачивания, больше - выровнять по ногам.")
        if cx.max() - cx.min() > max(3, 0.08 * h_ref):
            issues.append(f"Центр по горизонтали гуляет на {cx.max() - cx.min():.0f} px: персонаж «едет» внутри ячейки. Для цикла на месте выровнять по центру масс/пивоту.")
        if hh.max() / max(hh.min(), 1) > 1.12:
            issues.append(f"Высота фигуры меняется от {hh.min()} до {hh.max()} px (>12%): персонаж пульсирует в размере - признак разного масштаба генераций.")
        if len(full) >= 3:
            def dist(i, j):
                return abs(full[i]["bottom"] - full[j]["bottom"]) + abs(full[i]["cx"] - full[j]["cx"]) + abs(full[i]["height"] - full[j]["height"])
            steps = [dist(i, i + 1) for i in range(len(full) - 1)]
            loop = dist(len(full) - 1, 0)
            if loop > 2.5 * (np.median(steps) + 1):
                issues.append(f"Шов цикла: переход последний->первый кадр ({loop:.0f}) заметно резче обычного шага ({np.median(steps):.0f}). Анимация будет дёргаться на повторе.")
    pals_full = [p for p in pals if p]
    if len(pals_full) >= 2:
        union = set().union(*pals_full)
        inter = set.intersection(*pals_full)
        res_share = len(inter) / max(len(union), 1)
        if res_share < 0.35:
            issues.append(f"Палитра мерцает: общих цветов между кадрами {res_share:.0%}. Свести все кадры к одной общей палитре, иначе оттенки будут «переливаться».")
    if a.gif:
        bg = (128, 128, 128, 255)
        gif = [Image.alpha_composite(Image.new("RGBA", f.size, bg), f).convert("P", palette=Image.ADAPTIVE) for f in frames]
        gif[0].save(a.gif, save_all=True, append_images=gif[1:], duration=int(1000 / a.fps), loop=0, disposal=2)
    if not issues:
        issues.append("OK: ноги, центр, размер и палитра стабильны.")
    if a.json:
        print(json.dumps({"frames": stats, "issues": issues}, ensure_ascii=False, indent=1))
    else:
        print(f"Кадров: {len(frames)}")
        for s in stats:
            print("  ", s)
        for i in issues:
            print(" -", i)
        if a.gif:
            print("gif:", a.gif)


if __name__ == "__main__":
    main()
