#!/usr/bin/env python3
"""Sweep a video clip frame by frame for identity drift and artefacts.

Usage: python3 video_frames.py CLIP.mp4 OUT_DIR [--fps 2] [--cols 6]

Extracts frames (default 2 per second, enough to catch a defect that appears mid-shot)
with ffmpeg and builds a numbered contact sheet, so every moment of the clip can be
checked against the hero's reference list. A first/last frame check alone misses drift
that fades in mid-clip.
"""
import argparse, glob, os, shutil, subprocess, sys

from PIL import Image, ImageDraw


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("clip")
    p.add_argument("out")
    p.add_argument("--fps", type=float, default=2)
    p.add_argument("--cols", type=int, default=6)
    p.add_argument("--width", type=int, default=320)
    a = p.parse_args()
    if not shutil.which("ffmpeg"):
        sys.exit("Нужен ffmpeg. Без него: Magnific video_view_frames / video_extract_frames.")
    os.makedirs(a.out, exist_ok=True)
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", a.clip, "-vf", f"fps={a.fps}", os.path.join(a.out, "f_%04d.png")], check=True)
    files = sorted(glob.glob(os.path.join(a.out, "f_*.png")))
    if not files:
        sys.exit("Кадры не извлечены.")
    ims = []
    for f in files:
        im = Image.open(f).convert("RGB")
        im.thumbnail((a.width, a.width))
        ims.append(im)
    w, h = ims[0].size
    rows = (len(ims) + a.cols - 1) // a.cols
    sheet = Image.new("RGB", (w * a.cols, (h + 18) * rows), (20, 20, 20))
    d = ImageDraw.Draw(sheet)
    for i, im in enumerate(ims):
        x, y = (i % a.cols) * w, (i // a.cols) * (h + 18)
        sheet.paste(im, (x, y + 18))
        d.text((x + 4, y + 3), f"{i + 1}  t={i / a.fps:.1f}s", fill=(230, 230, 230))
    out = os.path.join(a.out, "contact_sheet.jpg")
    sheet.save(out, quality=88)
    print(f"Кадров: {len(files)}; лист: {out}")


if __name__ == "__main__":
    main()
