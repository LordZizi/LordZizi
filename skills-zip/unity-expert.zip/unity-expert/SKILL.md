---
name: unity-expert
description: 'Экспертная работа в Unity 6 (URP) на компьютере с Windows, часть 1 (главная) - управление Unity через batch mode и проверка сборок, архитектура C# (данные, события, сохранения, Input System), геймплей и ИИ врагов (NavMesh, физика), анимация и камеры, свет и рендер URP, производительность. Части 2 и 3 - unity-expert-visuals и unity-expert-production. Используй для задач в Unity вместе с официальным плагином Unity. Граница: экспертиза и проверки. Запуск редактора, CLI и пакеты - официальный плагин Unity (unity:*).'
license: MIT
metadata:
  version: 1.0.0-win
  author: LordZizi
  source: https://github.com/scenario-labs/skills (game-engines/unity, MIT), адаптировано под Windows и без сервиса Scenario
---

# Unity: эксперт (часть 1 - код, геймплей, анимация, свет, производительность)

Объединённый набор из 14 скиллов Scenario для Unity 6.3 (6000.3) URP. Каждый специалист - в своей папке рядом с этим файлом, инструкция - `GUIDE.md` (английский), процедуры - `references/procedures.md`, скрипты Python и C# (AgentKit) - в `scripts/`. Сервис Scenario не нужен.

**Всегда начинай с** `scenario-unity-expert/GUIDE.md` - как агент управляет Unity (batch mode, `-executeMethod`, живой редактор, проверка результата), затем GUIDE.md нужного специалиста.

## Карта специалистов

Unity разделён на три скилла (лимит 200 файлов на архив). В этом - **код и геймплей**; модуль управления Unity `scenario-unity-expert` есть в каждом.

| Задача | Где |
|---|---|
| Управление Unity, batch mode, сборки, проверки | `scenario-unity-expert` (здесь) |
| Архитектура C#: данные, события, сохранения, Input System | `scenario-unity-architecture` (здесь) |
| Геймплей: ИИ врагов, NavMesh, физика, стрельба | `scenario-unity-gameplay` (здесь) |
| 2D: спрайты, PPU, атласы, тайлмапы, 2D-свет | скилл **unity-expert-visuals**, папка `scenario-unity-2d` |
| Анимация персонажей, Animator, камеры Cinemachine | `scenario-unity-animation` (здесь) |
| UI: меню, настройки, HUD | скилл **unity-expert-visuals**, папка `scenario-unity-ui` |
| VFX: Particle System, VFX Graph | скилл **unity-expert-visuals**, папка `scenario-unity-vfx` |
| Шейдеры: HLSL, Shader Graph | скилл **unity-expert-visuals**, папка `scenario-unity-shaders` |
| URP, свет, лайтмапы, пост-обработка | `scenario-unity-rendering-lighting` (здесь) |
| Уровни и открытый мир: террейн, растительность, ProBuilder | скилл **unity-expert-production**, папка `scenario-unity-world-building` |
| Производительность: профайлер, draw calls, GC | `scenario-unity-performance` (здесь) |
| Телефоны: бюджет кадра, перегрев, тач | скилл **unity-expert-production**, папка `scenario-unity-mobile` |
| Веб-сборка: WebGL/WebGPU, сжатие, размер | скилл **unity-expert-visuals**, папка `scenario-unity-web` |
| Конвейер: импорт арта, префабы, сборки | скилл **unity-expert-production**, папка `scenario-unity-pipeline-automation` |

Если GUIDE.md отсылает к специалисту из другого скилла - открой его в том скилле (они установлены рядом).

Метка `<skills>` в путях - это **папка этого скилла**. Скрипты находят общие скрипты в `scenario-unity-expert/scripts` сами - не переставляй папки.

## Официальный плагин Unity и этот скилл

У пользователя установлен **официальный плагин Unity** (скиллы `unity:*`, в том числе `unity:unity-cli` для управления редактором). Он сделан Unity и рассчитан на все системы - **для запуска редактора, команд CLI, пакетов предпочитай его**. Этот скилл добавляет экспертизу: как правильно строить системы, что проверять, типичные ошибки и проверенные процедуры. Используй их вместе.

## Где это работает

Нужен Claude Code на компьютере с Unity: приложение Claude (Desktop), Claude Code в терминале или облачная сессия, подключённая к папке на компьютере. В обычном чате скилл только пишет код и шаги.

## Windows: что изменено и что заменить

Скрипты `scenario-unity-expert/scripts` доработаны под Windows (ветки `IS_WIN`):
- редактор ищется в `C:\Program Files\Unity\Hub\Editor\<версия>\Editor\Unity.exe`; другой путь - переменная `UNITY_EDITOR` (полный путь к Unity.exe) или `UNITY_HUB_EDITORS`;
- лицензия: `%LOCALAPPDATA%\Unity\licenses\` и `C:\ProgramData\Unity\Unity_lic.ulf`;
- список процессов Unity - через PowerShell, блокировка проекта - через msvcrt;
- **важно:** проверка «жив ли процесс» на Windows идёт через `tasklist`, потому что `os.kill(pid, 0)` на Windows не проверяет, а завершает процесс.

Эти правки не проверены на реальном Windows - при первом запуске сначала вызови `ut_env.find_editor()` и проверку лицензии и убедись, что пути найдены, прежде чем запускать сборки.

Версия по умолчанию в скриптах - `6000.3.21f1`. Если стоит другая, передавай `version=` или задай `UNITY_EDITOR`.

| В GUIDE.md (macOS) | На Windows |
|---|---|
| `/Applications/Unity/Hub/Editor/<ver>/Unity.app/Contents/MacOS/Unity` | `C:\Program Files\Unity\Hub\Editor\<ver>\Editor\Unity.exe` |
| `Unity.app/Contents/Resources/...` | `<ver>\Editor\Data\Resources\...` |
| `PlaybackEngines` внутри .app | `<ver>\Editor\Data\PlaybackEngines\` |
| сборка `macos`, `.app` | `windows64`, `.exe` |
| `/tmp/...`, `~/...` | `%TEMP%\...`, `%USERPROFILE%\...` |
| Metal | Direct3D 11/12 или Vulkan |

Пути с пробелами (`Program Files`) - всегда в кавычках.

## Связь с остальными скиллами

- Ассеты: **game-art-production** (генерация), **game-art-qa** (проверка), **blender-expert** (доводка и экспорт FBX/GLB).
- Звук в игре: **game-audio**.
