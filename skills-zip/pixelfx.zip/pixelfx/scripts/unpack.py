"""Unpack the bundled pixelfx library (assets/pixelfx-lib.json) into a folder.
Usage: python3 scripts/unpack.py DEST   (DEST, e.g. ./pixelfx, is created; existing files are not overwritten)"""
import json, os, sys
here = os.path.dirname(os.path.abspath(__file__))
dest = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "pixelfx")
data = json.load(open(os.path.join(here, "..", "assets", "pixelfx-lib.json"), encoding="utf-8"))
n = 0
for rel, text in data["files"].items():
    path = os.path.normpath(os.path.join(dest, rel))
    if not path.startswith(dest + os.sep):
        continue
    if os.path.exists(path):
        continue
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    n += 1
print("pixelfx", data["version"], "->", dest, "files written:", n)
