# Иконки и цвета, встроенные в страницу

Иконки (Lucide 0.460.0), которые рисуются без интернета на любом устройстве:

ArrowRight, Blocks, BookImage, BookOpen, Bot, Box, Boxes, Brain, BrainCircuit, Brush, Bug, ChartColumn, Check, ChevronDown, ChevronRight, ChevronUp, CircleAlert, Clapperboard, Clock, Cloud, CodeXml, Component, Cone, Copy, Crosshair, Cuboid, FileSpreadsheet, FileText, Film, Flame, FlaskConical, Footprints, Frame, Gamepad2, Gauge, Gem, Globe, Highlighter, Images, Joystick, Keyboard, Layers, LayoutGrid, LayoutTemplate, Lightbulb, Link, LoaderCircle, Map, Megaphone, Monitor, MousePointerClick, Music, Network, PaintBucket, Paintbrush, Palette, PenTool, Pencil, PersonStanding, Play, Plug, Presentation, Puzzle, Repeat, Rocket, RotateCcw, Scale, ScanEye, ScanFace, Search, Send, Settings, Shapes, Shield, ShieldCheck, SlidersHorizontal, Sparkles, SprayCan, SquareTerminal, Stamp, Star, Tag, Target, Telescope, TriangleAlert, Type, Upload, UserRound, Users, Volume2, VolumeX, WandSparkles, Wrench, X

Другое имя Lucide страница попробует догрузить с jsDelivr, а если не выйдет - покажет иконку направления. Надёжнее выбирать из списка.

## Палитры (пары цветов для градиента плиток)

- green: ["#22c55e", "#06b6d4"
- orange: ["#fb923c", "#f43f5e"
- pink: ["#f472b6", "#a855f7"
- violet: ["#a78bfa", "#6366f1"
- amber: ["#fbbf24", "#f97316"
- sky: ["#38bdf8", "#6366f1"
- blue: ["#60a5fa", "#22c55e"
- teal: ["#2dd4bf", "#3b82f6"
- lime: ["#a3e635", "#14b8a6"
- indigo: ["#818cf8", "#38bdf8"
- slate: ["#94a3b8", "#475569"
- rose: ["#fb7185", "#f59e0b"

## Встроенные направления (category) с иконками

- "Игры и 3D": ["Gamepad2", P.green
- "Аддоны Blender": ["Box", P.orange
- "Дизайн и бренд": ["Palette", P.pink
- "Графика, видео, звук": ["Images", P.violet
- "Видео": ["Film", P.rose
- "Документы и офис": ["FileText", P.amber
- "Страницы и визуализация": ["LayoutTemplate", P.sky
- "Google": ["Cloud", P.blue
- "Код и разработка": ["CodeXml", P.teal
- "Исследования": ["Telescope", P.lime
- "Браузер и компьютер": ["Monitor", P.indigo
- "Настройка Claude": ["SlidersHorizontal", P.slate

Другие направления задаются в коллекции categories (см. SKILL.md).
