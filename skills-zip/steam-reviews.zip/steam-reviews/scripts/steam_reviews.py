#!/usr/bin/env python3
"""Steam reviews toolkit: search games, read store info, download reviews, build stats and a reading digest.

Only public Steam endpoints, no API key, standard library only.

  python3 steam_reviews.py search "hades"
  python3 steam_reviews.py info 1145360 --cc ru --lang russian
  python3 steam_reviews.py reviews 1145360 --max 600 --lang all --out hades.jsonl
  python3 steam_reviews.py reviews 1145360 --type negative --lang russian --max 200 --out neg_ru.jsonl
  python3 steam_reviews.py stats hades.jsonl
  python3 steam_reviews.py digest hades.jsonl --per-group 40 --chars 600 > digest.md
  python3 steam_reviews.py news 1145360 --count 15
  python3 steam_reviews.py csv hades.jsonl hades.csv
"""
import argparse
import collections
import csv
import datetime as dt
import json
import random
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

STORE = "https://store.steampowered.com"
API = "https://api.steampowered.com"
UA = "Mozilla/5.0 (compatible; steam-reviews-skill/1.0)"


def fetch_json(url, params=None, tries=5):
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    delay = 2.0
    for attempt in range(tries):
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504) and attempt < tries - 1:
                time.sleep(delay)
                delay *= 2
                continue
            raise SystemExit(f"HTTP {e.code} for {url}")
        except (urllib.error.URLError, TimeoutError) as e:
            if attempt < tries - 1:
                time.sleep(delay)
                delay *= 2
                continue
            raise SystemExit(f"Network error for {url}: {e}. If this runs in a sandbox, allow store.steampowered.com and api.steampowered.com.")


def out(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))


# ---------- search / info / news ----------

def cmd_search(a):
    d = fetch_json(f"{STORE}/api/storesearch/", {"term": a.term, "l": "english", "cc": a.cc})
    out([{"appid": i.get("id"), "name": i.get("name"),
          "price": (i.get("price") or {}).get("final", 0) / 100 if i.get("price") else "free/none",
          "metascore": i.get("metascore") or None} for i in d.get("items", [])[: a.limit]])


def cmd_info(a):
    d = fetch_json(f"{STORE}/api/appdetails", {"appids": a.appid, "cc": a.cc, "l": a.lang}).get(str(a.appid), {})
    if not d.get("success"):
        raise SystemExit(f"No store data for app {a.appid} (region {a.cc})")
    g = d["data"]
    summ = fetch_json(f"{STORE}/appreviews/{a.appid}", {"json": 1, "language": "all", "purchase_type": "all",
                                                       "num_per_page": 0}).get("query_summary", {})
    po = g.get("price_overview") or {}
    out({
        "appid": a.appid, "name": g.get("name"), "type": g.get("type"),
        "release": (g.get("release_date") or {}).get("date"),
        "developers": g.get("developers"), "publishers": g.get("publishers"),
        "price": po.get("final_formatted") or ("free" if g.get("is_free") else None),
        "discount_percent": po.get("discount_percent"),
        "genres": [x["description"] for x in g.get("genres", [])],
        "categories": [x["description"] for x in g.get("categories", [])],
        "short_description": g.get("short_description"),
        "metacritic": (g.get("metacritic") or {}).get("score"),
        "recommendations": (g.get("recommendations") or {}).get("total"),
        "reviews_all_languages": {k: summ.get(k) for k in ("review_score_desc", "total_positive", "total_negative", "total_reviews")},
        "store_url": f"{STORE}/app/{a.appid}/",
    })


def cmd_news(a):
    d = fetch_json(f"{API}/ISteamNews/GetNewsForApp/v2/", {"appid": a.appid, "count": a.count, "maxlength": a.chars})
    items = d.get("appnews", {}).get("newsitems", [])
    out([{"date": dt.datetime.fromtimestamp(i["date"], dt.timezone.utc).strftime("%Y-%m-%d"), "title": i.get("title"),
          "feed": i.get("feedlabel"), "url": i.get("url"), "text": i.get("contents")} for i in items])


# ---------- reviews ----------

def slim(r, appid):
    au = r.get("author", {})
    sid = au.get("steamid")
    return {
        "id": r.get("recommendationid"),
        "voted_up": r.get("voted_up"),
        "language": r.get("language"),
        "created": dt.datetime.fromtimestamp(r.get("timestamp_created", 0), dt.timezone.utc).strftime("%Y-%m-%d"),
        "updated": dt.datetime.fromtimestamp(r.get("timestamp_updated", 0), dt.timezone.utc).strftime("%Y-%m-%d"),
        "playtime_at_review_h": round((au.get("playtime_at_review") or 0) / 60, 1),
        "playtime_total_h": round((au.get("playtime_forever") or 0) / 60, 1),
        "author_reviews": au.get("num_reviews"),
        "votes_helpful": r.get("votes_up", 0),
        "votes_funny": r.get("votes_funny", 0),
        "comments": r.get("comment_count", 0),
        "steam_purchase": r.get("steam_purchase"),
        "free_key": r.get("received_for_free"),
        "early_access": r.get("written_during_early_access"),
        "steam_deck": r.get("primarily_steam_deck"),
        "dev_reply": bool(r.get("developer_response")),
        "text": (r.get("review") or "").strip(),
        "url": f"https://steamcommunity.com/profiles/{sid}/recommended/{appid}/" if sid else None,
    }


def cmd_reviews(a):
    params = {"json": 1, "filter": a.filter, "language": a.lang, "review_type": a.type,
              "purchase_type": "all", "num_per_page": 100}
    if a.days:
        params["filter"] = "all"          # day_range only applies to the "all" (helpfulness) order
        params["day_range"] = min(a.days, 365)
    if a.include_offtopic:
        params["filter_offtopic_activity"] = 0
    cursor, seen_cursors, got, summary = "*", set(), [], None
    while len(got) < a.max:
        params["cursor"] = cursor
        d = fetch_json(f"{STORE}/appreviews/{a.appid}", params)
        if d.get("success") != 1:
            raise SystemExit(f"Steam returned success={d.get('success')} for app {a.appid}")
        if summary is None:
            summary = d.get("query_summary", {})
        batch = d.get("reviews", [])
        if not batch:
            break
        for r in batch:
            if a.min_chars and len(r.get("review") or "") < a.min_chars:
                continue
            got.append(slim(r, a.appid))
            if len(got) >= a.max:
                break
        cursor = d.get("cursor")
        if not cursor or cursor in seen_cursors:
            break
        seen_cursors.add(cursor)
        print(f"... {len(got)} reviews", file=sys.stderr)
        time.sleep(a.sleep)
    with open(a.out, "w", encoding="utf-8") as f:
        for r in got:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    out({"saved": a.out, "count": len(got), "query": {k: v for k, v in params.items() if k != "cursor"},
         "steam_summary_for_query": summary})


def load(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(x) for x in f if x.strip()]


def bucket_playtime(h):
    for lim, name in ((2, "<2h (refund window)"), (10, "2-10h"), (50, "10-50h"), (200, "50-200h")):
        if h < lim:
            return name
    return "200h+"


def share(rows):
    n = len(rows)
    pos = sum(1 for r in rows if r["voted_up"])
    return {"n": n, "positive_pct": round(100 * pos / n, 1) if n else None}


def cmd_stats(a):
    rows = load(a.file)
    if not rows:
        raise SystemExit("empty file")
    res = {"overall": share(rows)}
    for key, fn in (("by_language", lambda r: r["language"]),
                    ("by_playtime_at_review", lambda r: bucket_playtime(r["playtime_at_review_h"])),
                    ("by_month", lambda r: r["created"][:7]),
                    ("by_length", lambda r: "short <100 chars" if len(r["text"]) < 100 else ("medium" if len(r["text"]) < 600 else "long 600+"))):
        groups = collections.defaultdict(list)
        for r in rows:
            groups[fn(r)].append(r)
        order = sorted(groups) if key == "by_month" else sorted(groups, key=lambda k: -len(groups[k]))
        res[key] = {k: share(groups[k]) for k in order}
    flags = {}
    for f in ("steam_deck", "early_access", "free_key", "dev_reply"):
        sub = [r for r in rows if r.get(f)]
        if sub:
            flags[f] = share(sub)
    res["flags"] = flags
    pt = sorted(r["playtime_at_review_h"] for r in rows)
    res["median_playtime_at_review_h"] = pt[len(pt) // 2]
    res["date_range"] = [min(r["created"] for r in rows), max(r["created"] for r in rows)]
    res["most_helpful"] = [{"voted_up": r["voted_up"], "helpful": r["votes_helpful"], "lang": r["language"],
                            "text": r["text"][:200], "url": r["url"]}
                           for r in sorted(rows, key=lambda r: -r["votes_helpful"])[:5]]
    out(res)


def cmd_digest(a):
    """Compact markdown for reading: groups by verdict (and language), most helpful first, then random fill."""
    rows = [r for r in load(a.file) if len(r["text"]) >= a.min_chars]
    rnd = random.Random(7)
    groups = collections.defaultdict(list)
    for r in rows:
        key = ("POSITIVE" if r["voted_up"] else "NEGATIVE") + (f" / {r['language']}" if a.by_lang else "")
        groups[key].append(r)
    for key in sorted(groups):
        g = groups[key]
        top = sorted(g, key=lambda r: -r["votes_helpful"])[: a.per_group // 2]
        rest = [r for r in g if r not in top]
        rnd.shuffle(rest)
        pick = top + rest[: a.per_group - len(top)]
        print(f"\n## {key} - showing {len(pick)} of {len(g)}\n")
        for i, r in enumerate(pick, 1):
            t = " ".join(r["text"].split())
            if len(t) > a.chars:
                t = t[: a.chars] + "..."
            print(f"[{key[0]}{i}] {r['playtime_at_review_h']}h, {r['created']}, helpful {r['votes_helpful']}"
                  f"{', Deck' if r.get('steam_deck') else ''} | {t}")
            if a.links and r.get("url"):
                print(f"    {r['url']}")


def cmd_csv(a):
    rows = load(a.file)
    with open(a.out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"saved {a.out} ({len(rows)} rows)")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    s = p.add_subparsers(dest="cmd", required=True)

    x = s.add_parser("search"); x.add_argument("term"); x.add_argument("--cc", default="us"); x.add_argument("--limit", type=int, default=10)
    x.set_defaults(fn=cmd_search)
    x = s.add_parser("info"); x.add_argument("appid", type=int); x.add_argument("--cc", default="us"); x.add_argument("--lang", default="english")
    x.set_defaults(fn=cmd_info)
    x = s.add_parser("news"); x.add_argument("appid", type=int); x.add_argument("--count", type=int, default=10); x.add_argument("--chars", type=int, default=600)
    x.set_defaults(fn=cmd_news)

    x = s.add_parser("reviews"); x.add_argument("appid", type=int)
    x.add_argument("--max", type=int, default=500)
    x.add_argument("--lang", default="all", help="all | english | russian | schinese | german | ... (Steam API language names)")
    x.add_argument("--type", default="all", choices=["all", "positive", "negative"])
    x.add_argument("--filter", default="recent", choices=["recent", "updated", "all"], help="recent = newest first; all = most helpful first")
    x.add_argument("--days", type=int, default=0, help="only the last N days (max 365); switches to helpfulness order")
    x.add_argument("--min-chars", type=int, default=0, help="skip reviews shorter than this")
    x.add_argument("--include-offtopic", action="store_true", help="include review-bomb periods Steam hides by default")
    x.add_argument("--sleep", type=float, default=1.0)
    x.add_argument("--out", required=True)
    x.set_defaults(fn=cmd_reviews)

    x = s.add_parser("stats"); x.add_argument("file"); x.set_defaults(fn=cmd_stats)
    x = s.add_parser("digest"); x.add_argument("file")
    x.add_argument("--per-group", type=int, default=40); x.add_argument("--chars", type=int, default=500)
    x.add_argument("--min-chars", type=int, default=40); x.add_argument("--by-lang", action="store_true"); x.add_argument("--links", action="store_true")
    x.set_defaults(fn=cmd_digest)
    x = s.add_parser("csv"); x.add_argument("file"); x.add_argument("out"); x.set_defaults(fn=cmd_csv)

    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
