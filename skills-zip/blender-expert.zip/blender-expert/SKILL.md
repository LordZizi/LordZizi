---
name: blender-expert
description: Экспертная работа в Blender через Python на компьютере пользователя с Windows - моделирование, скульпт персонажа и головы, ретопология AI-моделей, UV и запекание, текстуры и материалы, риг и веса, анимация и циклы, геометрические ноды, свет и рендер, Grease Pencil, превиз и экспорт в Unity, Godot или GLB. Опыт ~200 видео экспертов Blender Studio и Blender Conference, со скриптами проверки. Используй для любой задачи в Blender, в том числе доводки моделей из Tripo, Meshy и Magnific.
license: MIT
metadata:
  version: "1.0.0-win"
  author: "LordZizi"
  source: "https://github.com/scenario-labs/skills (dcc/blender, MIT), адаптировано под Windows и без сервиса Scenario"
---

# Blender: эксперт

Это объединённый набор из 15 скиллов Scenario для Blender 5.x. Каждый специалист лежит в своей папке рядом с этим файлом, его инструкция - `GUIDE.md` (английский). Сервис Scenario не нужен: всё работает через обычный Python в Blender.

**Всегда начинай с** `scenario-blender-expert/GUIDE.md` - протокол работы (канал выполнения, цикл «сделал - посмотрел - измерил - исправил», ловушки API 5.x), затем открой GUIDE.md нужного специалиста.

## Карта специалистов

| Задача | Папка |
|---|---|
| Протокол, проверки (`bx_review`, `bx_audit`), ловушки API | `scenario-blender-expert` |
| Скульпт: голова, лицо, персонаж, существо | `scenario-blender-sculpting` |
| Ретопология скульпта, скана или AI-модели под бюджет | `scenario-blender-retopology` |
| UV, швы, упаковка, плотность текселей, запекание карт | `scenario-blender-uv-baking` |
| Материалы и текстуры, PBR, износ, грязь, декали | `scenario-blender-texturing-shading` |
| Хард-сёрфейс: оружие, техника, пропсы | `scenario-blender-hard-surface` |
| Риг: Rigify, веса, контроллеры | `scenario-blender-rigging` |
| Анимация: ходьба, бег, прыжок, актёрская игра, липсинк | `scenario-blender-animation` |
| Волосы и мех, hair cards для игр | `scenario-blender-hair` |
| Геометрические ноды, раскидывание, процедурка, симуляции | `scenario-blender-geometry-nodes` |
| Свет, рендер, EEVEE/Cycles, композитинг | `scenario-blender-lighting-rendering` |
| Grease Pencil: 2D-анимация, вырезная анимация | `scenario-blender-grease-pencil` |
| Превиз, раскадровка, аниматик | `scenario-blender-previs-storyboard` |
| Блокаут сцены под видео-модель (Seedance) | `scenario-blender-blockout` |
| Экспорт в Unity, Unreal, Godot, GLB, печать | `scenario-blender-export` |

Метка `<skills>` в путях внутри GUIDE.md и procedures.md - это **папка этого скилла** (где лежит этот SKILL.md). Скрипты специалистов сами находят общие скрипты в `scenario-blender-expert/scripts` - не переставляй папки.

## Где это работает

Скилл управляет Blender на **компьютере пользователя**, поэтому нужен Claude Code там же:
- приложение Claude (Desktop) или Claude Code в терминале на этом компьютере;
- или облачная сессия, подключённая к папке на компьютере (Remote Control).

В обычном чате claude.ai без доступа к компьютеру скилл может только писать скрипты и объяснять шаги - запустить их пользователь должен сам.

## Windows: что заменить в инструкциях

Инструкции писались на Mac. На Windows:

| В GUIDE.md (macOS) | На Windows |
|---|---|
| `blender` в командах | полный путь: `"C:\Program Files\Blender Foundation\Blender 5.x\blender.exe"` (найди фактическую версию: `dir "C:\Program Files\Blender Foundation"`). Удобно один раз задать переменную `BLENDER` |
| `/Applications/Blender.app/Contents/Resources/5.x/...` | `C:\Program Files\Blender Foundation\Blender 5.x\5.x\...` |
| `/opt/homebrew/bin/blender` | путь выше |
| GPU `METAL` | `OPTIX` (NVIDIA RTX), `CUDA` (NVIDIA), `HIP` (AMD); скрипт материалов выбирает CUDA сам |
| `/tmp/...` | `%TEMP%\...` или папка проекта |
| `~/...` | `%USERPROFILE%\...` |

Пути в Python пиши через прямые слэши или `r"C:\..."`. Пути с пробелами - в кавычках.

## Каналы выполнения

- **Фоновый Blender (по умолчанию):** `"%BLENDER%" -b file.blend --factory-startup --python-exit-code 1 -P script.py -- аргументы`. Для рендеров, проверок, пакетных операций. `--factory-startup` - чтобы аддоны пользователя не вмешивались, `--python-exit-code 1` - чтобы ошибка не выглядела успехом.
- **Живой Blender пользователя** - через MCP-аддон для Blender (например, BlenderMCP). Таблица в `scenario-blender-expert/GUIDE.md` описывает плагин Scenario, которого у пользователя нет: используй инструменты своего аддона (выполнение Python, скриншот вьюпорта, сведения о сцене) по тому же принципу. Одно короткое изменение за вызов, перед изменениями - резервная копия файла.
- Не открывай новые окна Blender на компьютере пользователя - либо его открытый Blender, либо фоновый.

## Связь с остальными скиллами

- Модели из Tripo, Meshy, Magnific -> `scenario-blender-retopology` и `scenario-blender-uv-baking` -> `scenario-blender-export`.
- Проверка результата - также скилл **game-art-qa** (`check_glb.py` для экспортированного GLB).
- Платные аддоны пользователя (Instant Rigger and Animator, Animal Rigger Pro, Faceit, Smart Material Painter, SimpleBake), если установлены, можно использовать вместо ручных шагов рига и текстур - спроси пользователя, какие стоят.
